<div class="footer">
  <div class="footer-container">
    <div class="logo">
      <a href="/dentalook/index.php">
        <img src="/images/footer-logo.svg" alt="Logo" class="mb-3 logo-img">
      </a>
    </div>

    <div class="footer-text-group">
      <div class="copy">Copyright © <span id="year"></span> Nexcent ltd.</div>
      <div class="copy">All rights reserved</div>
    </div>

    <div class="d-flex gap-3">
      <!-- Instagram Link -->
      <a href="https://www.instagram.com" class="footer-social-icon" target="_blank">
        <img src="/images/social-icons/instagram.svg" alt="Instagram" width="24" height="24">
      </a>

      <!-- Website Link -->
      <a href="https://www.yourwebsite.com" class="footer-social-icon" target="_blank">
        <img src="/images/social-icons/website.svg" alt="Website" width="24" height="24">
      </a>

      <!-- X (formerly Twitter) Link -->
      <a href="https://twitter.com" class="footer-social-icon" target="_blank">
        <img src="/images/social-icons/x.svg" alt="X" width="24" height="24">
      </a>

      <!-- YouTube Link -->
      <a href="https://www.youtube.com" class="footer-social-icon" target="_blank">
        <img src="/images/social-icons/youtube.svg" alt="YouTube" width="24" height="24">
      </a>
    </div>

  </div>

  <div class="footer-columns">

  <!-- Company Section -->
  <div class="footer-section">
    <div class="footer-heading">Company</div>
    <div class="footer-links">
      <a href="#statistics" class="link">About us</a>
      <a href="#faq" class="link">Blog</a>
      <a href="#features" class="link">Contact us</a>
      <a href="#testimonial" class="link">Pricing</a>
      <a href="#testimonial" class="link">Testimonials</a> 
    </div>
  </div>

  <!-- Support Section -->
  <div class="footer-section">
    <div class="footer-heading">Support</div>
    <div class="footer-links">
      <a href="#faq" class="link">Help center</a> 
      <a href="https://www.linkedin.com/legal/privacy-policy" class="link">Terms of service</a>
      <a href="https://www.linkedin.com/legal/privacy-policy" class="link">Legal</a> <!-- External link -->
      <a href="https://www.linkedin.com/legal/privacy-policy" class="link" target="_blank">Privacy policy</a> <!-- External link -->
      <a href="https://www.linkedin.com/legal/privacy-policy" class="link" target="_blank">Status</a> <!-- External link -->
    </div>
  </div>

    <div class="footer-section">
      <div class="footer-heading">Stay up to date</div>
      <div class="position-relative">
        <input type="text" class="form-control transparent-input p-4 custom-input" placeholder="Your email address">
        <img src="/images/contactus.svg" alt="search icon"
             class="position-absolute top-50 end-0 translate-middle-y me-3" width="20" height="20">
      </div>
    </div>
  </div>
</div>

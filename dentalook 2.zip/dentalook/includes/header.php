<div class="container d-flex">

  <nav class="navbar navbar-expand-lg navbar-light bg-white px-3 container-fluid d-flex justify-content-between align-items-center">
    <div class=" d-flex align-items-center justify-content-between burger-menu">
      <!-- Burger Menu - far left always -->
      <button class="navbar-toggler me-2" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent"
        aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Logo - centered on mobile, left on desktop -->
      <a class="navbar-brand me-4" href="/dentalook/index.php">
        <img src="/images/logo.svg" alt="Logo" height="40">
      </a>
    </div>

    <!-- Collapse nav links + mobile login/signup -->
    <div class="collapse navbar-collapse flex-grow-1 justify-content-center" id="navbarContent">
      <ul class="navbar-nav mx-auto text-center gap-lg-3 mb-3 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#statistics">Service</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#features">Feature</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#benefits">Product</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#testimonial">Testimonial</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#faq">FAQ</a>
        </li>
      </ul>

      <!-- Mobile-only login/signup -->
      <div class="d-flex d-lg-none justify-content-center gap-2 mt-2">
        <a class="btn login text-green" href="https://www.linkedin.com/login">Login</a>
        <a class="btn signup px-3" href="https://www.linkedin.com/signup">Sign Up</a>
      </div>
    </div>
    <!-- Desktop Login/Signup - far right only visible on lg+ -->

    <div class="d-flex gap-2 login-btns d-none d-lg-flex gap-2">
    <a class="btn login text-green" href="https://www.linkedin.com/login">Login</a>
    <a class="btn signup px-3" href="https://www.linkedin.com/signup">Sign Up</a>
  </div>

  </nav>
</div>
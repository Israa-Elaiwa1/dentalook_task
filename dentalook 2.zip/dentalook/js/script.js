$(document).ready(function () {
  document.getElementById('year').textContent = new Date().getFullYear();
    function revealStats() {
      var stats = $('.statistics');
      var statsTop = stats.offset().top;
      var scrollTop = $(window).scrollTop();
      var windowHeight = $(window).height();

      if (scrollTop + windowHeight > statsTop + 100) {
        stats.addClass('visible');
      }
    }

    function revealTestimonials() {
      var testimonials = $('.testimonial-wrapper');
      var testimonialsTop = testimonials.offset().top;
      var scrollTop = $(window).scrollTop();
      var windowHeight = $(window).height();

      if (scrollTop + windowHeight > testimonialsTop + 100) {
        testimonials.addClass('visible');
      }
    }

    function revealDemo() {
      var demo = $('.demo-wrapper');
      var demoTop = demo.offset().top;
      var scrollTop = $(window).scrollTop();
      var windowHeight = $(window).height();

      if (scrollTop + windowHeight > demoTop + 100) {
        demo.addClass('visible');
      }
    }
    // reveal sections when scrolling to them
    $(window).on('scroll', revealStats);
    revealStats();

    $(window).on('scroll', revealTestimonials);
    revealTestimonials();

    $(window).on('scroll', revealDemo);
    revealDemo(); 

  });

